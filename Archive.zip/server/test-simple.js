// Simple test file to verify module resolution
console.log('Simple test file loaded');

export function hello(name) {
  return `Hello, ${name}!`;
}

console.log('Test function defined');
