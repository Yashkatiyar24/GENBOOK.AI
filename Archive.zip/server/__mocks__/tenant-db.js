module.exports = { tenantDB: (_req, _res, next) => next() };
