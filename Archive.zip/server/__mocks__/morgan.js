module.exports = function morgan() {
  return (_req, _res, next) => next();
};
