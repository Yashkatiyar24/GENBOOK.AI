module.exports = { initializeDatabase: async () => {} };
