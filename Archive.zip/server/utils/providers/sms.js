import { sendSMS } from '../../providers/sms.js';
export { sendSMS };
export default { sendSMS };
