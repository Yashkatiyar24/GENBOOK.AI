import { sendEmail } from '../../providers/email.js';
export { sendEmail };
export default { sendEmail };
